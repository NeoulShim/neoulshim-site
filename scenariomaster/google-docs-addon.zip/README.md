# Google Docs 출력 뷰어 1.2.1 (QA 수정본)

인물명은 `$태수`처럼 달러 기호로 시작하고, 바로 다음 줄에 대사를 씁니다. 지문은 빈 줄로 구분합니다. 이전 인물명 기호는 지원하지 않습니다.

Google Docs에서 원고를 함께 편집하고, 문서 안의 뷰어에서 대본 문법을 해석해 HWPX·PDF로 출력합니다. 정식 Marketplace 승인은 아직 완료되지 않았습니다. 1.2.1은 여러 계정이 로그인된 Chrome에서도 현재 원고를 자동 갱신하는 QA 수정본입니다.

일반 사용자는 기능이 설치된 QA 문서의 사본으로 시작하는 방법을 권장합니다. 코드 복사 설치는 개발자용입니다. 현재는 설치·사용 통계를 외부로 보내지 않습니다.

프로젝트 이름과 원고 문서 제목은 자유입니다. ‘제목 없는 프로젝트’여도 작동합니다. [설치 안내](https://neoulshim.kr/scenariomaster/install.html) · [그림으로 보는 사용법](https://neoulshim.kr/scenariomaster/guide.html).

1. 기능이 설치된 문서에서 **시나리오의 거장 → Docs 안에서 열기**를 선택합니다. 현재 원고와 작업 중인 탭이 바로 표시됩니다.
2. 처음 한 번 **자동 갱신 연결**을 눌러 현재 Docs와 같은 계정을 승인합니다. 원고를 다시 고르지 않습니다.
3. 원문은 Docs에서 계속 편집합니다. 연결되면 글의 추가·수정·삭제를 자동 반영합니다. **글꼴 · 용지 · 양식**에서 바꾼 출력 형식은 유지됩니다.
4. **한글 HWPX**로 내려받거나 **PDF 저장 / 인쇄**에서 PDF로 저장합니다. 인쇄는 배율 100%, 여백 없음, 브라우저 머리글·바닥글 끄기를 권장합니다.

수동 설치: 이 묶음의 `Code.gs`는 독립 Editor add-on 프로젝트용입니다. `Code.gs`와 `appsscript.json`을 저장하고 Google Docs 테스트 배포를 설정합니다. 문서에 직접 설치하는 코드는 저장소의 `docs-addon/template/Code.gs`입니다. `Viewer.html`은 기존 설치 호환용이며 1.2.1 기본 메뉴는 neoulshim.kr 뷰어를 Docs 창 안에서 엽니다. 고급 Docs 서비스는 필요하지 않습니다.

## 수정 이력

원고의 수정 이력과 이전 버전 복원은 Google Docs 기본 버전 기록을 사용합니다.

## 데이터와 권한

원본을 수정·삭제하지 않으며 공동 편집과 원본 이력은 Google Docs가 담당합니다. 메뉴 실행 시 현재 원고를 읽고, 이후 갱신은 Google에서 브라우저로 직접 읽습니다. 자동 갱신 연결의 권한 자체는 모든 Docs를 읽을 수 있지만 앱은 메뉴에서 받은 현재 문서 ID로만 읽기 요청을 보냅니다. 계정 확인과 연결 유지에 필요한 인증정보만 서버에 암호화하여 보관합니다. 자세한 권한과 보관 기간은 아래 항목과 [개인정보 안내](https://neoulshim.kr/scenariomaster/privacy.html)를 확인하세요. 공유 문서의 바운드 스크립트는 문서 편집자가 확인·수정할 수 있습니다.

공식 문서: [문서 탭](https://developers.google.com/workspace/docs/api/how-tos/tabs), [수정 제안](https://developers.google.com/workspace/docs/api/how-tos/suggestions), [대화상자](https://developers.google.com/apps-script/guides/dialogs).

HWPX 기본 패키지 출처와 Apache-2.0 라이선스는 `THIRD_PARTY_NOTICES.md`, `LICENSE-python-hwpx.txt`를 확인하세요.

## 문서 이미지

Docs의 삽입 → 이미지로 넣은 사진을 창을 열 때 Google 안에서 읽고 미리보기·HWPX·PDF에 포함합니다. 이미지는 브라우저 메모리에만 보관하며 연결 서버에 보내지 않습니다. 글은 자동 갱신되고, 이미지를 추가·교체한 경우에는 창을 닫고 다시 열어야 합니다. 처음 보는 이미지가 생기면 누락 방지를 위해 내보내기를 멈추고 다시 열도록 안내합니다. 텍스트 줄 안 배치를 권장하며 감싸기 이미지는 연결된 문단 다음에 배치합니다.

## 1.2.1 QA — 현재 원고와 자동 갱신 연결
Docs 안에서 열기를 누르면 현재 원고와 작업 중인 문서 탭을 바로 표시합니다. 처음 한 번 ‘자동 갱신 연결’로 같은 Google 계정을 승인하면 이후 갱신은 Docs API로 직접 읽습니다. 원고를 다시 선택하지 않으며 Apps Script 후속 RPC를 사용하지 않습니다. 연결은 HttpOnly 파티션 쿠키와 서버의 AES-GCM 암호화 저장으로 최대 30일 유지합니다. ‘연결 안내 → 자동 갱신 연결 해제’로 해제합니다.

Apps Script는 currentonly·container.ui·userinfo.email을 사용합니다. 별도 웹 연결은 documents.readonly·openid·email을 사용합니다. 권한 자체는 계정의 모든 Docs를 읽을 수 있지만 앱은 메뉴에서 받은 현재 문서 ID에 대해서만 GET 요청을 보냅니다. 연결 서버는 인증정보만 처리하며 원고·문서 ID를 받지 않습니다.

2026-09-27: 자동 테스트 75개·TypeScript 통과. 실제 여러 계정 Chrome에서 현재 원고 즉시 표시, 문장 추가·수정·삭제 자동 반영, 창을 다시 열었을 때 승인 없이 연결 유지까지 확인했습니다. 시험 문장을 지워 원문을 복원했습니다. 이미지가 유지된 실제 HWPX를 내려받아 원문·이미지 포함과 시험 문장 제거를 확인했습니다. Marketplace 승인은 대기 중입니다.
